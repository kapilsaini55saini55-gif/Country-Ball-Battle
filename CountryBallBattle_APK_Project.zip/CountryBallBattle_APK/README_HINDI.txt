COUNTRY BALL BATTLE - APK (mobile + PC dono ke liye)
Ye APK phone, tablet, Chromebook aur PC (BlueStacks / LDPlayer / Windows Android emulator) par chalta hai.
Screen rotate ho sakti hai, keyboard (Arrow/WASD, Esc, F) aur mouse bhi kaam karte hain.

APK banane ka tarika (GitHub, free):
1) github.com par free account -> New repository (naam: CountryBallBattle) -> Public.
2) "uploading an existing file" -> is folder ke SAARE files/folders (.github folder bhi) drag karke upload karo -> Commit.
3) "Actions" tab -> "Build APK" (3-5 min). Green tick par us run ko kholo.
4) Neeche Artifacts -> CountryBallBattle-APK download -> zip kholo -> app-debug.apk install karo.
Android Studio se: folder open karo -> Build > Build APK(s).
Game badalna ho to app/src/main/assets/index.html edit karo.
